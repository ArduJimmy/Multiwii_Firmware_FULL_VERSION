This application was created on Windows, which does not
properly support setting files as "executable",
a necessity for applications on Mac OS X.

To fix this, use the Terminal on Mac OS X, and from this
directory, type the following:

chmod +x MultiWiiConf_2_0.app/Contents/MacOS/JavaApplicationStub
